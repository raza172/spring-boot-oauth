package com.org.oauthapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthappApplicationTests {

	@Test
	void contextLoads() {
	}

}
