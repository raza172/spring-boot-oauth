package com.org.oauthapp.service;

import java.util.ArrayList;
import java.util.List;
import com.org.oauthapp.model.Posts;

public class PostService {
	
	public List<Posts> getPosts(){
		
		List<Posts> list=new ArrayList();
		Posts post=new Posts();
		
		post.setPostId(1);
		post.setPostName("facebook post");
		post.setPostType("profile pic");
		post.setPostImage("image url");
		list.add(post);
		
		return list;
	}

}
