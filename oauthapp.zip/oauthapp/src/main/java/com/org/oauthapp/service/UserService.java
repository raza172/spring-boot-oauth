package com.org.oauthapp.service;

import java.util.ArrayList;
import java.util.List;

import com.org.oauthapp.model.Users;

public class UserService {

	
	public List<Users> getUsersList() {	
		List<Users> userList= new ArrayList();
		Users user1=new Users();
		user1.setId("1");
		user1.setName("Kashan");
		user1.setEmail("kashi@gmail.com");
		user1.setStatus("Active");
		user1.setAge("32");
		userList.add(user1);
		
		Users user2=new Users();
		user2.setId("2");
		user2.setName("Usman");
		user2.setEmail("mani@gmail.com");
		user2.setStatus("Active");
		user2.setAge("32");
		userList.add(user2);
		
		return userList;
	}
}
