package com.org.oauthapp.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.org.oauthapp.model.Posts;
import com.org.oauthapp.service.PostService;

@RestController
@RequestMapping("/api/posts")
public class PostController {
	
	List<Posts> postList;
	PostService postService=new PostService();
	
	
	@GetMapping("/all")
	public List<Posts> getAllUsers(){
		//returning posts list
		return postService.getPosts();
	}

	
	

}