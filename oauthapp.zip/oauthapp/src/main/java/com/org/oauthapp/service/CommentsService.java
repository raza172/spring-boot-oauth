package com.org.oauthapp.service;

import java.util.ArrayList;
import java.util.List;
import com.org.oauthapp.model.Comments;

public class CommentsService {
	
	public List<Comments> getComments(){
		List<Comments> list =new ArrayList();
		
		Comments comment=new Comments();
		comment.setCommentId(1);
		comment.setPostId(1);
		comment.setComment("very good ");
		list.add(comment);
		return list;
	}

}
