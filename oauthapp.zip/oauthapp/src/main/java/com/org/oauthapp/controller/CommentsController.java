package com.org.oauthapp.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.org.oauthapp.model.Comments;
import com.org.oauthapp.service.CommentsService;

@RestController
@RequestMapping("/api/comments")
public class CommentsController {
	
	List<Comments> commentList;
	CommentsService commentService=new CommentsService();
	
	
	@GetMapping("/all")
	public List<Comments> getAllUsers(){
		//returning comments list
		return commentService.getComments();
	}

	
	

}